﻿using Microsoft.AspNetCore.Mvc;
using StudentAssessment.Entities;

namespace StudentAssessment.Controllers
{
    public class StudentController : Controller
    {
        private readonly Assessment4Context _context;

        public StudentController()
        {
            _context = new Assessment4Context();
        }
        [HttpGet]
        public IActionResult Index()
        {
            try
            {
                var students = _context.Students;
                return View(students);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        public IActionResult Details(int id)
        {
            var student = _context.Students.Single(p => p.StudentId == id);
            return View(student);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Students.Add(student);
                    _context.SaveChanges();
                    return RedirectToAction("Index");

                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        public IActionResult GetStudentById(int id)
        {
            try
            {
                var student = _context.Students.SingleOrDefault(n => n.StudentId == id);
                return View(student);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            try
            {
                var student = _context.Students.SingleOrDefault(n => n.StudentId == id);
                return View(student);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }

        }
        [HttpPost]
        public IActionResult Edit(Student student)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    _context.Students.Update(student);
                    _context.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
        
        [HttpGet]
        public IActionResult Delete(int id)
        {
            try
            {
                var student = _context.Students.SingleOrDefault(n => n.StudentId == id);
                return View(student);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }

        }
        [HttpPost]
        public IActionResult Delete(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Students.Remove(student);
                    _context.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }



    }
}
