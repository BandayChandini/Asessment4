﻿using Microsoft.AspNetCore.Mvc;
using StudentAssessment.Entities;

namespace StudentAssessment.Controllers
{
    public class CompanyController : Controller
    {
        private readonly Assessment4Context _context;

        public CompanyController()
        {
            _context= new Assessment4Context();
        }
        [HttpGet]
        public IActionResult Index()
        {
            try
            {
                var companies = _context.Companies;
                return View(companies);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Company company)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Companies.Add(company);
                    _context.SaveChanges();
                    return RedirectToAction("Index");

                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
    }
}
